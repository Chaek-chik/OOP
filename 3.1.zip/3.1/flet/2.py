import flet as ft

def main(page: ft.Page):
    pass

ft.app(target=main, view=ft.WEB_BROWSER)
